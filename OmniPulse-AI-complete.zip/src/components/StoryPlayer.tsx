import React, { useEffect, useRef, useState } from 'react';
import { Play, Pause, ChevronLeft, ChevronRight, Volume2, VolumeX, Download, Loader2, AlertTriangle, FileText } from 'lucide-react';
import { GeneratedVideo } from '../types';

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
/** How long a line takes to say, so captions follow the speech. */
const phraseMs = (text: string) => Math.max(850, Math.min(2400, (text.trim().split(/\s+/).length / 2.6 + 0.25) * 1000));
const captionPhrases = (text: string) => { const words = text.trim().split(/\s+/).filter(Boolean); const out: string[] = []; for (let i = 0; i < words.length; i += 5) out.push(words.slice(i, i + 5).join(' ')); return out; };

/** Builds an editable sidecar subtitle file from the approved screenplay lines.
 * Timing is estimated within each scene because source clips do not expose word-level timestamps. */
const subtitleTimestamp = (seconds: number) => {
  const ms = Math.max(0, Math.round(seconds * 1000));
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const wholeSeconds = Math.floor((ms % 60000) / 1000);
  const millis = ms % 1000;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(wholeSeconds).padStart(2, '0')},${String(millis).padStart(3, '0')}`;
};
const buildSrt = (items: GeneratedVideo['scenes']) => {
  let offset = 0;
  let cueNumber = 1;
  const cues: string[] = [];
  for (const scene of items) {
    // Prefer real speech timestamps when available; fall back to estimated screenplay timing.
    const duration = Math.max(0.5, Number(scene.duration) || 4);
    const timedCaptions = (scene.captions || []).filter((cue) => String(cue.text || '').trim() && Number.isFinite(Number(cue.start)) && Number.isFinite(Number(cue.end)));
    if (timedCaptions.length) {
      timedCaptions.forEach((cue) => {
        const start = offset + Math.max(0, Number(cue.start) || 0);
        const end = offset + Math.max(Number(cue.start) + 0.12, Number(cue.end) || 0);
        cues.push(`${cueNumber++}\n${subtitleTimestamp(start)} --> ${subtitleTimestamp(end)}\n${String(cue.text).trim()}`);
      });
      offset += duration;
      continue;
    }
    const lines = (scene.lines || []).filter((line) => String(line.text || '').trim());
    // Respect explicit first/second-half dialogue timing when present. Older scenes
    // without timing metadata keep the previous whole-scene estimate.
    const hasHalfTiming = duration >= 20 && lines.some((line) => line.half === 1 || line.half === 2);
    const groups = hasHalfTiming
      ? [lines.filter((line) => (line.half || 1) === 1), lines.filter((line) => line.half === 2)]
      : [lines];
    const segmentDuration = duration / groups.length;
    groups.forEach((group, groupIndex) => {
      const phrases = group.flatMap((line) => captionPhrases(String(line.text || '')).filter(Boolean));
      const gap = phrases.length > 1 ? Math.min(0.12, segmentDuration / (phrases.length * 4)) : 0;
      const usable = Math.max(0.2, segmentDuration - gap * Math.max(0, phrases.length - 1));
      const weights = phrases.map((phrase) => Math.max(1, phrase.split(/\s+/).length));
      const totalWeight = weights.reduce((sum, weight) => sum + weight, 0) || 1;
      let cursor = offset + groupIndex * segmentDuration;
      phrases.forEach((phrase, index) => {
        const span = Math.max(0.18, usable * weights[index] / totalWeight);
        const end = Math.min(offset + (groupIndex + 1) * segmentDuration, cursor + span);
        cues.push(`${cueNumber++}\n${subtitleTimestamp(cursor)} --> ${subtitleTimestamp(Math.max(cursor + 0.12, end))}\n${phrase}`);
        cursor = end + gap;
      });
    });
    offset += duration;
  }
  return cues.join('\n\n') + (cues.length ? '\n' : '');
};
/**
 * Plays a multi-character production. The video engine makes the pictures and the voices together, so the sound always matches.
 * Two video elements take turns: while one plays, the other already loads the next scene, so scene changes do not stall.
 */
export const StoryPlayer: React.FC<{ video: GeneratedVideo }> = ({ video }) => {
  const scenes = video.scenes;
  const sceneSignature = scenes.map((scene) => scene.id).join('|');
  const characters = video.characters || [];
  const [idx, setIdx] = useState(0);
  const [front, setFront] = useState<0 | 1>(0);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [caption, setCaption] = useState<string | null>(null);
  const [join, setJoin] = useState<{ state: 'idle' | 'working' | 'error'; msg: string }>({ state: 'idle', msg: '' });
  const run = useRef(0);
  const mutedRef = useRef(false);
  const refs = [useRef<HTMLVideoElement | null>(null), useRef<HTMLVideoElement | null>(null)];

  const load = (el: HTMLVideoElement | null, url?: string) => {
    if (!el || !url) return;
    if (el.dataset.src !== url) { el.dataset.src = url; el.src = url; el.preload = 'auto'; el.load(); }
  };

  useEffect(() => {
    run.current++;
    setIdx(0); setFront(0); setPlaying(false); setCaption(null);
    load(refs[0].current, scenes[0]?.clipUrl);
    load(refs[1].current, scenes[1]?.clipUrl);
    return () => { run.current++; refs.forEach((r) => r.current?.pause()); };
  }, [video.id, sceneSignature]);

  useEffect(() => { mutedRef.current = muted; refs.forEach((r, i) => { if (r.current && i === front) r.current.muted = muted; }); }, [muted, front]);

  const stop = () => {
    run.current++;
    refs.forEach((r) => r.current?.pause());
    setPlaying(false);
    setCaption(null);
  };

  const playFrom = async (start: number) => {
    const myRun = ++run.current;
    setPlaying(true);
    // Warm up the other video element inside the tap, so the browser lets it play by itself later.
    const warm = refs[(start + 1) % 2].current;
    if (warm) { warm.muted = true; warm.play().then(() => warm.pause()).catch(() => undefined); }
    for (let i = start; i < scenes.length; i++) {
      if (run.current !== myRun) return;
      const sc = scenes[i];
      const el = refs[i % 2].current, other = refs[(i + 1) % 2].current;
      if (!el || !sc.clipUrl) continue;
      setIdx(i); setFront((i % 2) as 0 | 1);
      load(el, sc.clipUrl);
      other?.pause();
      el.muted = mutedRef.current;
      try { el.currentTime = 0; } catch { /* not ready yet */ }
      const ended = new Promise<void>((res) => { el.onended = () => res(); setTimeout(res, (sc.duration + 3) * 1000); });
      try { await el.play(); } catch { setPlaying(false); return; }
      load(other, scenes[i + 1]?.clipUrl); // start loading the next scene right away
      const captions = (async () => {
        for (const line of sc.lines || []) {
          for (const phrase of captionPhrases(line.text)) {
            if (run.current !== myRun) return;
            setCaption(phrase);
            await wait(phraseMs(phrase));
          }
        }
        setCaption(null);
      })();
      await Promise.all([ended, captions]);
    }
    if (run.current === myRun) { setPlaying(false); setCaption(null); }
  };

  const jump = (i: number) => {
    const was = playing;
    stop();
    setIdx(i); setFront((i % 2) as 0 | 1);
    load(refs[i % 2].current, scenes[i]?.clipUrl);
    if (was) playFrom(i);
  };

  const ids = scenes.map((s) => s.clipJobId).filter(Boolean) as string[];
  const fileName = (video.title || 'omnipulse-video').replace(/[^\w\- ]+/g, '').trim().slice(0, 60) || 'omnipulse-video';
  const downloadSubtitles = () => {
    const content = buildSrt(scenes);
    if (!content.trim()) return;
    const blob = new Blob([content], { type: 'application/x-subrip;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}.srt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 10000);
  };

  const downloadAll = () => {
    if (!ids.length) {
      setJoin({ state: 'error', msg: 'This production has no downloadable scene jobs.' });
      return;
    }
    const url = `/api/video/merge?ids=${encodeURIComponent(ids.join(','))}&name=${encodeURIComponent(fileName)}`;
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}.mp4`;
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setJoin({ state: 'idle', msg: 'The server is joining the scenes and will stream the MP4 to your downloads when it is ready.' });
  };

  const ratio = video.aspectRatio === '16:9' ? '16 / 9' : video.aspectRatio === '1:1' ? '1 / 1' : '9 / 16';
  const maxW = video.aspectRatio === '9:16' ? 300 : 560;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4 sm:p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-bold text-white">{video.title}</h2>
          <p className="text-xs text-slate-400">{video.format ? video.format[0].toUpperCase() + video.format.slice(1) : 'Production'} · {scenes.length} scenes · {video.estimatedDuration} seconds · {characters.length} characters</p>
        </div>
        <button onClick={() => setMuted((m) => !m)} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-slate-200" aria-pressed={muted}>
          {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}{muted ? 'Sound off' : 'Sound on'}
        </button>
      </div>

      <div className="relative mx-auto bg-black rounded-xl overflow-hidden border border-slate-800" style={{ aspectRatio: ratio, width: '100%', maxWidth: maxW, maxHeight: 520 }}>
        {[0, 1].map((n) => (
          <video key={n} ref={refs[n]} playsInline preload="auto" className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${front === n ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} />
        ))}
        {caption && (
          <div className="absolute inset-x-0 bottom-0 p-3 bg-linear-to-t from-black/85 to-transparent text-center pointer-events-none">
            <p className="inline-block max-w-[92%] rounded-lg bg-black/70 px-3 py-2 text-sm font-semibold text-white leading-snug shadow-lg">{caption}</p>
          </div>
        )}
        {!playing && (
          <button onClick={() => playFrom(idx)} aria-label="Play" className="absolute inset-0 flex items-center justify-center bg-black/30">
            <span className="w-14 h-14 rounded-full bg-indigo-600 flex items-center justify-center shadow-lg"><Play className="w-6 h-6 text-white ml-0.5" /></span>
          </button>
        )}
        {scenes[idx]?.onScreenText && (
          <div className={`pointer-events-none absolute left-1/2 z-10 w-[88%] -translate-x-1/2 text-center ${scenes[idx].overlayPosition === 'top' ? 'top-8' : scenes[idx].overlayPosition === 'bottom' ? 'bottom-16' : 'top-1/2 -translate-y-1/2'}`}>
            <span className={scenes[idx].overlayStyle === 'minimal'
              ? 'inline-block bg-transparent px-2 py-1 text-base font-bold tracking-wide text-white [text-shadow:0_2px_8px_rgba(0,0,0,0.95)]'
              : scenes[idx].overlayStyle === 'lower_third'
                ? 'inline-block max-w-full border-l-4 border-indigo-400 bg-slate-950/85 px-4 py-2 text-left text-sm font-semibold text-white shadow-2xl'
                : 'inline-block rounded-lg border border-white/20 bg-black/65 px-4 py-2 text-base font-extrabold tracking-wide text-white shadow-2xl'}>{scenes[idx].onScreenText}</span>
          </div>
        )}
      </div>

      <div className="flex items-center justify-center gap-3">
        <button onClick={() => jump(Math.max(0, idx - 1))} disabled={idx === 0} aria-label="Previous scene" className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
        <button onClick={() => (playing ? stop() : playFrom(idx))} className="px-5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-2">
          {playing ? <><Pause className="w-4 h-4" />Pause</> : <><Play className="w-4 h-4" />Play from scene {idx + 1}</>}
        </button>
        <button onClick={() => jump(Math.min(scenes.length - 1, idx + 1))} disabled={idx >= scenes.length - 1} aria-label="Next scene" className="p-2 rounded-lg bg-slate-800 border border-slate-700 text-slate-200 disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-950 p-3 space-y-2">
        <button onClick={downloadAll} disabled={join.state === 'working' || !ids.length} className="w-full py-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white text-xs font-semibold flex items-center justify-center gap-2">
          {join.state === 'working' ? <><Loader2 className="w-4 h-4 animate-spin" />Joining scenes...</> : <><Download className="w-4 h-4" />Download full video (one MP4)</>}
        </button>
        <button onClick={downloadSubtitles} disabled={!scenes.some((scene) => scene.captions?.some((cue) => cue.text?.trim()) || scene.lines?.some((line) => line.text?.trim()))} className="w-full py-2.5 rounded-lg border border-slate-700 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2">
          <FileText className="w-4 h-4" />Download subtitles (.SRT)
        </button>
        <p className="text-[10px] text-slate-500">Uses real speech timestamps when available, otherwise estimates timing from the screenplay. Downloads a separate subtitle file; captions are not burned into the MP4.</p>
        {join.msg && (
          <p role={join.state === 'error' ? 'alert' : 'status'} className={`text-[11px] flex items-start gap-1.5 ${join.state === 'error' ? 'text-rose-300' : 'text-slate-400'}`}>
            {join.state === 'error' && <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />}{join.msg}
          </p>
        )}
      </div>

      <div>
        <p className="text-xs font-semibold text-slate-300 mb-2">Cast</p>
        <div className="flex flex-wrap gap-2">
          {characters.map((c) => (
            <span key={c.id} className="text-[11px] rounded-full border border-slate-700 bg-slate-950 px-3 py-1 text-slate-300"><span className="font-semibold text-white">{c.name}</span> · {c.role || 'character'}</span>
          ))}
        </div>
      </div>

      <ol className="space-y-2">
        {scenes.map((s, i) => (
          <li key={s.id} className={`rounded-lg border p-3 ${i === idx ? 'border-indigo-500 bg-indigo-950/30' : 'border-slate-800 bg-slate-950'}`}>
            <div className="flex items-center justify-between gap-2">
              <button onClick={() => jump(i)} className="text-[11px] font-semibold text-indigo-300 text-left">Scene {i + 1}{s.beat ? ` · ${s.beat}` : ''} · {s.duration}s</button>
              {(s.clipJobId || s.clipUrl) && (
                <a href={s.clipJobId ? `/api/video/download?id=${encodeURIComponent(s.clipJobId)}&name=${encodeURIComponent(`${fileName} scene ${i + 1}`)}` : s.clipUrl} download target={s.clipJobId ? undefined : '_blank'} rel="noopener noreferrer"
                  className="text-[11px] text-slate-400 hover:text-slate-200 flex items-center gap-1" aria-label={`Download scene ${i + 1}`}><Download className="w-3 h-3" />Download</a>
              )}
            </div>
            {s.cameraMotion && <p className="text-[11px] text-slate-500 mt-1">Camera: {s.cameraMotion}</p>}
            {(s.lines || []).map((l, k) => <p key={k} className="text-xs text-slate-300 mt-1"><span className="font-semibold text-white">{l.speaker}:</span> {l.text}</p>)}
          </li>
        ))}
      </ol>
    </div>
  );
};
