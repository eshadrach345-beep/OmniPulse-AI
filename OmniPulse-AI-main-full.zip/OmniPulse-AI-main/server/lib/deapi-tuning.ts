export type DeapiVideoModelInfo = {
  info?: { features?: Record<string, unknown>; limits?: Record<string, unknown>; defaults?: Record<string, unknown> };
};

export type DeapiVideoOverrides = { negative_prompt?: unknown; guidance?: unknown; steps?: unknown };

export const DEAPI_VIDEO_NEGATIVE_PROMPT = [
  'malformed hands', 'deformed hands', 'extra fingers', 'fused fingers',
  'distorted limbs', 'duplicate people', 'duplicate faces', 'ghosting',
  'morphing', 'warping', 'melting', 'smearing', 'flicker', 'jitter',
  'unstable anatomy', 'floating objects', 'unreadable text', 'watermark',
  'screen-within-screen', 'phone status bar', 'collage',
].join(', ');

const finiteNumber = (value: unknown): number | null => {
  const n = typeof value === 'number' ? value : (typeof value === 'string' && value.trim() ? Number(value) : NaN);
  return Number.isFinite(n) ? n : null;
};
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

/** Converts live model capabilities/defaults into supported multipart fields. */
export function buildDeapiVideoFields(modelInfo: DeapiVideoModelInfo | null | undefined, overrides: DeapiVideoOverrides = {}): Record<string, string> {
  const info = modelInfo?.info || {};
  const features = info.features || {};
  const limits = info.limits || {};
  const defaults = info.defaults || {};
  const fields: Record<string, string> = {};
  if (features.supports_negative_prompt !== false) {
    const custom = typeof overrides.negative_prompt === 'string' ? overrides.negative_prompt.trim() : '';
    fields.negative_prompt = [DEAPI_VIDEO_NEGATIVE_PROMPT, custom].filter(Boolean).join(', ').slice(0, 1800);
  }
  if (features.supports_guidance === true) {
    const min = finiteNumber(limits.min_guidance) ?? 0;
    const max = finiteNumber(limits.max_guidance) ?? 30;
    const requested = finiteNumber(overrides.guidance) ?? finiteNumber(defaults.guidance) ?? 3;
    fields.guidance = String(clamp(requested, min, max));
  }
  if (features.supports_steps === true) {
    const min = finiteNumber(limits.min_steps) ?? 1;
    const max = finiteNumber(limits.max_steps) ?? 100;
    const requested = finiteNumber(overrides.steps) ?? finiteNumber(defaults.steps) ?? 20;
    fields.steps = String(Math.round(clamp(requested, min, max)));
  }
  return fields;
}

/** A per-attempt seed takes precedence over a configured fixed seed so QA retries can explore a new result. */
export function resolveDeapiSeed(seedOverride: unknown, configuredSeed: unknown, fallbackSeed: number): number {
  const valid = (value: unknown): number | null => {
    const n = typeof value === 'number' ? value : (typeof value === 'string' && value.trim() ? Number(value) : NaN);
    return Number.isSafeInteger(n) && n >= 0 && n <= 2_147_483_647 ? n : null;
  };
  return valid(seedOverride) ?? valid(configuredSeed) ?? fallbackSeed;
}

/**
 * Quality order used when nobody picked a model. Highest first. Matched against the model slug with
 * everything except letters and digits removed, so "Ltx2_5_22B_Dist_INT8" becomes "ltx2522bdistint8".
 * Override with DEAPI_MODEL_PREFERENCE (comma separated prefixes) or pin one model with DEAPI_VIDEO_MODEL.
 */
export const DEAPI_MODEL_PREFERENCE = ['seedance25', 'kling4', 'minimaxh3', 'veo31', 'ltx25', 'ltx23', 'ltxvideo13b'];

const slugKey = (slug: unknown) => String(slug || '').toLowerCase().replace(/[^a-z0-9]/g, '');

export function deapiModelRank(slug: string, preference: string[] = DEAPI_MODEL_PREFERENCE): number {
  const key = slugKey(slug);
  const index = preference.findIndex((prefix) => key.startsWith(slugKey(prefix)));
  return index === -1 ? preference.length : index;
}

/** Best available model for episode clips (needs 5 and 10 second support). Returns null when nothing qualifies. */
export function pickDeapiVideoModel(
  models: { slug: string; supportsStoryClipDurations?: boolean }[],
  preference: string[] = DEAPI_MODEL_PREFERENCE,
): string | null {
  const usable = models.filter((model) => model.supportsStoryClipDurations);
  if (!usable.length) return null;
  return [...usable].sort((a, b) => deapiModelRank(a.slug, preference) - deapiModelRank(b.slug, preference))[0].slug;
}

/**
 * LTX models are trained up to roughly 1024 px on the long side. Asking them for more (for example 768x1344)
 * is a common cause of duplicated faces and extra limbs, so LTX renders at its native size and the finishing
 * step (scripts/finish-video.mjs) scales the result up. Other models keep the requested size.
 */
export function deapiNativeCanvas(model: string, width: number, height: number): [number, number] {
  if (!slugKey(model).startsWith('ltx')) return [width, height];
  const longSide = Math.max(width, height);
  if (longSide <= 1024) return [width, height];
  const scale = 1024 / longSide;
  const snap = (value: number) => Math.max(256, Math.round((value * scale) / 32) * 32);
  return [snap(width), snap(height)];
}

/** Positive anatomy cues. Distilled video models run near guidance 1, where negative prompts barely register. */
export const DEAPI_QUALITY_SUFFIX = 'Natural hands with five fingers, one clear face per person, stable consistent faces, sharp detail, smooth natural motion, cinematic lighting.';

/**
 * Keeps the render prompt inside the length video models handle well (deAPI recommends 60-200 words) without cutting
 * mid-sentence, then adds the positive quality cues. The start of the prompt is kept because models weight it most.
 */
export function shapeDeapiPrompt(prompt: string, maxChars = 1500): string {
  const clean = String(prompt || '').replace(/\s+/g, ' ').trim();
  let body = clean;
  if (clean.length > maxChars) {
    const window = clean.slice(0, maxChars);
    const lastStop = Math.max(window.lastIndexOf('. '), window.lastIndexOf('! '), window.lastIndexOf('? '));
    body = lastStop > maxChars * 0.5 ? window.slice(0, lastStop + 1) : window.trimEnd();
  }
  return body.includes(DEAPI_QUALITY_SUFFIX) ? body : `${body} ${DEAPI_QUALITY_SUFFIX}`;
}
