# Video quality settings (deAPI)

## What changed
- **Model default**: when no model is chosen, the best model on your deAPI account is used (order: Seedance 2.5, Kling 4.0, MiniMax H3, Veo 3.1, LTX 2.5, LTX 2.3, LTX-Video 13B; only models that support 5 and 10 second clips). The Creator Canvas dropdown lists models in the same order.
- **Native canvas for LTX**: LTX renders vertical video at 576x1024 (not 768x1344). Larger sizes cause duplicated faces and extra limbs. Other models keep their requested size.
- **Prompt shaping**: render prompts are cut at a sentence boundary to about 1,500 characters and end with positive anatomy cues. The saved cast notes are shorter so the action stays at the front of the prompt.
- **Finishing**: `node scripts/finish-video.mjs in.mp4 out.mp4` upscales to 1080x1920 (Lanczos), lightly denoises, grades, adds fine grain and re-encodes at high quality.

## Environment variables
| Variable | Purpose |
|---|---|
| `DEAPI_VIDEO_MODEL` | Pin one model (exact slug from the Creator Canvas dropdown). **While on the free credit, pin a cheap LTX model; remove it after you top up.** |
| `DEAPI_MODEL_PREFERENCE` | Optional comma-separated slug prefixes, best first, e.g. `seedance25,kling4,ltx25` |
| `DEAPI_PROMPT_MAX_CHARS` | Prompt length cap (default 1500) |
| `DEAPI_VIDEO_INPUT` | Optional JSON, e.g. `{"guidance":1,"steps":8}`. Leave empty unless a model's page recommends values. |

## After deploying
1. `npm i && npm run build:api`, then commit `api/index.js` (the committed copy was an older build without the model catalogue and tuning code).
2. Open Creator Canvas, pick the model, render one 10 second clip, compare.
3. Run `scripts/finish-video.mjs` on the downloaded video for the polished look.
