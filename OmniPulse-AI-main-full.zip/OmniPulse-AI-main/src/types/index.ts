export type PlatformId = 'youtube' | 'tiktok' | 'instagram' | 'x' | 'linkedin' | 'facebook' | 'pinterest';

export interface SocialAccount {
  id: PlatformId;
  name: string;
  handle: string;
  avatarUrl: string;
  connected: boolean;
  followers: number;
  growthRate: number; // e.g. +14.2%
  engagementRate: number; // e.g. 5.8%
  peakTimes: string[];
  bestFormat: string;
  autoPilotEnabled: boolean;
  oauthToken?: string;
  connectedAt?: string;
  accountEmail?: string;
  /** Server says the site owner has added this network's developer keys. */
  configured?: boolean;
  /** Publishing to this network is implemented. */
  publishable?: boolean;
}

export interface ResearchSource {
  title: string; url: string; domain?: string; faviconUrl?: string; imageUrl?: string;
  snippet?: string; publishedAt?: string; sourceType?: 'video' | 'article' | 'news' | 'website'; platform?: string;
}

export interface NicheCategory {
  id: string;
  name: string;
  iconName: string;
  /** Category heading used to group niches in the dropdown. */
  group?: string;
  description: string;
  audienceDemographics: string;
  avgEngagementRate: string;
  /** Web pages the latest research was based on. */
  trendingTopics: TrendingTopic[];
  /** Creators / accounts found trending in this niche by live research. */
  trendingCreators?: TrendingCreator[];
  viralHashtags: HashtagGroup;
  suggestedKeywords: string[];
  bestPractices: BestPractice[];
  /** Rich source cards returned by live web research. */
  researchSources?: ResearchSource[];
  /** True when the research really used live web search. */
  researchGrounded?: boolean;
  /** Search provider(s) used for the latest radar refresh. */
  researchProvider?: string;
  /** ISO timestamp for the latest completed research scan. */
  researchedAt?: string;
}

export interface TrendingCreatorVideo {
  title: string;
  url: string;
  thumbnailUrl?: string;
  platform: string;
  publishedAt?: string;
  /** Public view count only; never private impressions. */
  views?: number | null;
  /** Calculated from public views and elapsed time; not platform-reported impressions. */
  viewsPerHour?: number | null;
  metricLabel?: string;
}
export interface TrendingCreator {
  rank?: number;
  name: string;
  handle: string;
  platform: string;
  /** Link to the profile or to the content the research found. */
  url?: string;
  avatarUrl?: string;
  rankingBasis?: string;
  /** Why this creator is trending right now. */
  whyTrending: string;
  /** The format / style of content that is working for them. */
  contentStyle: string;
  /** Concrete idea a user can adapt, not copy verbatim. */
  takeaway: string;
  /** Example hook or post idea inspired by their approach. */
  exampleHook?: string;
  /** Directly sourced recent videos with public metrics when available. */
  recentVideos?: TrendingCreatorVideo[];
}

export interface TrendingTopic {
  id: string;
  title: string;
  /** One sentence on why the topic is timely, from live research. */
  whyNow?: string;
  velocity: string; // e.g. "+420% this week"
  sentiment: 'Hot' | 'Rising' | 'Breakout' | 'Evergreen';
  recommendedFormat: 'TikTok/Reels 9:16' | 'YouTube 16:9' | 'Carousels' | 'Shorts';
  viralHooks: string[];
  contentAngle: string;
  estimatedReachMultiplier: string;
}

export interface HashtagItem {
  tag: string;
  volume: string; // e.g. "2.4M posts"
  competition: 'Low' | 'Medium' | 'High' | 'Unknown';
  velocityScore: number; // 1-100
  category: 'viral' | 'niche' | 'evergreen';
  /** Whether the tag appeared in a dated source or was generated as an idea. */
  evidenceStatus?: 'verified' | 'suggested';
}

export interface HashtagGroup {
  viral: HashtagItem[];
  nicheSpecific: HashtagItem[];
  evergreen: HashtagItem[];
}

export interface BestPractice {
  title: string;
  category: 'Follower Growth' | 'Sales & Conversion' | 'Retention & Watch Time' | 'Algorithm Triggers';
  insight: string;
  actionableStep: string;
}

export type VideoType = 
  | 'ad_video' 
  | 'doodle_video' 
  | 'explainer_video'
  | 'cartoon_3d'
  | 'cartoon_2d'
  | 'real_video'
  | 'cgi_3d';

export type AspectRatioType = '9:16' | '16:9' | '1:1';
export type VideoDirectorStyle = 'dynamic_viral' | 'cinematic_commercial' | 'creator_storyteller' | 'retention_master';
export type HookFormulaStyle = 'witty_provocative' | 'contrarian' | 'viral_breakout' | 'raw_founder' | 'witty_sarcastic';
export type AIDirectorEngine = VideoDirectorStyle;
export type GrokHookStyle = HookFormulaStyle;

/** How long the production should run: Short Form (15-30s) or Long Form Narrative (1-2 min). */
export type DurationMode = 'short' | 'long';
/** Global story genre / emotion. Drives lighting, pacing, colour grade and writing tone for every scene. */
export type StoryMoodId = 'dramatic_suspense' | 'melodrama' | 'viral_hook' | 'emotional_heartfelt' | 'cinematic_trailer';
/** Directorial camera profile. Translated into a concrete cameraMotion instruction for every scene. */
export type CameraProfileId = 'slow_dramatic_zoom' | 'steady_pan' | 'static_narrative' | 'kinetic_tracking';
export type PresentationId = 'movie' | 'dialogue' | 'narrated' | 'shortdrama';
export type CastId = 'people' | 'animals' | 'mythical' | 'mixed';
export type TropeId = 'none' | 'hidden_identity' | 'revenge' | 'contract_marriage' | 'betrayal' | 'rags_to_riches' | 'secret_child' | 'love_triangle' | 'family_secret' | 'ceo_romance' | 'fake_dating';
export type GenreId = 'auto' | 'action' | 'thriller' | 'scifi' | 'fantasy' | 'horror' | 'romance' | 'comedy' | 'noir' | 'western' | 'superhero' | 'mystery' | 'adventure' | 'heist' | 'disaster' | 'wildlife' | 'mythical' | 'monster';
export type IntensityId = 'calm' | 'balanced' | 'max';
export type DialogueId = 'none' | 'minimal' | 'normal';
export type EndingId = 'cliffhanger' | 'resolved' | 'twist';

/** The creative brief the user configured. Sent to the script writer and stored on the finished video. */
export interface StoryBrief {
  durationMode: DurationMode;
  /** Length the user asked for, in seconds (before any plan-allowance cap). */
  requestedSeconds: number;
  /** One scene is 20 seconds (two 10 second clips) or 10 seconds. */
  sceneSeconds?: 10 | 20;
  mood: StoryMoodId;
  cameraProfile: CameraProfileId;
  /** Movie, dialogue drama or narrated story. Videos made before this option existed have none of these. */
  presentation?: PresentationId;
  genre?: GenreId;
  intensity?: IntensityId;
  dialogue?: DialogueId;
  ending?: EndingId;
  cast?: CastId;
  animalsTalk?: boolean;
  trope?: TropeId;
  /** Optional main-character lock: this descriptor is repeated in every scene so the person looks the same. */
  characterLock?: { name?: string; descriptor: string };
}

export interface VideoCharacter {
  id: string;
  name: string;
  role: string;
  gender: 'male' | 'female';
  /** Visual description repeated in every scene prompt so the character looks the same. */
  description: string;
  /** Studio voice id, or 'none' for a silent character. */
  voiceId?: string;
}

export interface SceneLine { speaker: string; text: string; half?: 1 | 2; emotion?: string; doing?: string }
export type VideoMediaLayerKind = 'video' | 'image' | 'audio';
export type VideoMediaTrack = 'main' | 'overlay' | 'audio';

/** A persistent reference to a private creator-library asset. Never store temporary signed URLs here. */
export interface VideoMediaLayer {
  id: string;
  assetId: string;
  name: string;
  contentType: string;
  kind: VideoMediaLayerKind;
  track: VideoMediaTrack;
  startAt: number;
  sourceIn: number;
  duration: number;
  volume: number;
  /** Optional audio envelope fades, in seconds. */
  fadeIn?: number;
  fadeOut?: number;
  opacity: number;
  scale: number;
  x: number;
  y: number;
  /** Optional chroma-key cleanup for green-screen image/video overlays. */
  chromaKey?: boolean;
  chromaKeyColor?: string;
  chromaKeySimilarity?: number;
  chromaKeyBlend?: number;
}

export interface VideoCaptionCue {
  start: number;
  end: number;
  text: string;
}

/** Timed text layer, previewed in the editor and composited into the exported MP4. */
export interface VideoTextOverlay {
  id: string;
  start: number;
  end: number;
  text: string;
  y: 'h*0.12' | 'h*0.5' | 'h*0.78';
  fontSize: number;
  color?: string;
  boxColor?: string;
  boxBorderWidth?: number;
  fadeIn?: number;
  fadeOut?: number;
  weight?: 'regular' | 'bold';
}


export interface VideoScene {
  id: string;
  /** Multi-character productions: what each character says in this scene. */
  /** Private creator-library sources and overlays, stored by asset ID rather than expiring URL. */
  mediaLayers?: VideoMediaLayer[];
  /** Word/segment-timed captions created from source-media transcription. */
  captions?: VideoCaptionCue[];
  /** Timed exportable text and title graphics. */
  textOverlays?: VideoTextOverlay[];
  /** Source in-point for a generated provider clip when there is no explicit main media layer. */
  sourceIn?: number;
  lines?: SceneLine[];
  /** Multi-character productions: the rendered clip for this scene. */
  clipUrl?: string;
  /** The render job of this scene's clip. Used to download or join the scenes. */
  clipJobId?: string;
  visualPrompt?: string;
  /** Spoken words of this scene (narration and dialogue, without speaker names). */
  voiceoverText?: string;
  /** The camera instruction this scene was rendered with. */
  cameraMotion?: string;
  /** Story beat of this scene, e.g. "Hook" or "Climax". */
  beat?: string;
  sceneNumber: number;
  duration: number; // seconds
  /** Base footage playback rate; 1 is real time, 0.5 is half-speed, 2 is double-speed. */
  playbackSpeed?: number;
  /** Main scene fade in/out in seconds; applied to picture and source audio. */
  clipFadeIn?: number;
  clipFadeOut?: number;
  /** How the source frame fits into the output canvas. */
  fitMode?: 'contain' | 'cover';
  /** Restrained color-grading preset applied during export. */
  colorGrade?: 'none' | 'cinematic' | 'warm' | 'cool' | 'monochrome' | 'vintage' | 'vivid';
  visualCue: string;
  narration: string;
  onScreenText: string;
  /** Editor-controlled placement for the on-screen title overlay. */
  overlayPosition?: 'top' | 'center' | 'bottom';
  /** Visual treatment used for the title in the editor preview and exported MP4. */
  overlayStyle?: 'cinematic' | 'minimal' | 'lower_third';
  soundEffectCue: string;
  motionStyle: 'Dynamic Zoom' | 'Hand Sketch Draw' | 'Kinetic Kinetic Typography' | 'Isometric Pan';
  bgGradient: string;
  iconSymbol?: string;
}

export interface GeneratedVideo {
  id: string;
  title: string;
  userPrompt: string;
  videoType: VideoType;
  aspectRatio: AspectRatioType;
  targetPlatforms: PlatformId[];
  nicheId: string;
  estimatedDuration: number;
  scenes: VideoScene[];
  /** Set for drama, documentary and animation productions with several voices. */
  characters?: VideoCharacter[];
  format?: 'drama' | 'documentary' | 'animation' | 'commercial';
  /** Creative settings the production was made with (duration, mood, camera, character lock). */
  brief?: StoryBrief & { targetSeconds: number };
  voiceoverStyle: string;
  backgroundMusicTrack: string;
  thumbnailUrl: string;
  videoUrl?: string;
  /** Render job ID for authenticated, streamed downloads without browser-side buffering. */
  videoJobId?: string;
  createdAt: string;
  status: 'ready' | 'rendering' | 'scheduled' | 'published';
  directorStyle?: VideoDirectorStyle;
  hookFormula?: HookFormulaStyle;
  aiDirectorEngine?: AIDirectorEngine;
  grokHookStyle?: GrokHookStyle;
  voiceId?: string;
  voiceName?: string;
  voiceMomentum?: number;
  voiceQuality?: string;
  hashtags?: string[];
  soundDesignBadge?: string;
  callToAction?: string;
}

export interface ScheduledPost {
  id: string;
  title: string;
  caption: string;
  hashtags: string[];
  platforms: PlatformId[];
  mediaType: 'video' | 'image' | 'carousel';
  mediaUrl?: string;
  videoRefId?: string;
  scheduledTime: string; // ISO string
  status: 'draft' | 'scheduled' | 'publishing' | 'published';
  autoPeakOptimized: boolean;
  /** IDs returned by each network when this post was published, used to read real metrics later. */
  publishedPosts?: { postId: string; platform: string; name: string }[];
  metrics?: {
    views: number;
    likes: number;
    shares: number;
    comments: number;
    ctr: number;
  };
}

export interface NicheAutoPilotSettings {
  enabled: boolean;
  frequency: 'daily' | 'twice_daily' | 'weekly' | 'custom';
  videosPerBatch: number;
  preferredStyle: VideoType;
  customTimeSlot: string; // e.g. "18:30"
  targetPlatforms: PlatformId[];
  autoResearchTrending: boolean;
  lastAutonomousRun?: string;
}



export interface ABVariant {
  hook: string;
  caption: string;
  thumbnailDesc: string;
  /** Network post ID once the variant has been published. */
  postId?: string;
  channelId?: string;
  impressions?: number;
  engagements?: number;
}

export interface ABTestExperiment {
  id: string;
  name: string;
  targetPlatform: PlatformId;
  createdAt: string;
  hypothesis: string;
  strategicReasoning: string;
  videoRefId?: string;
  status: 'draft' | 'running' | 'completed';
  variantA: ABVariant;
  variantB: ABVariant;
  resultsSource?: 'network' | 'manual';
  winningVariant?: 'A' | 'B';
  confidenceRate?: number;
}
